import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Builds into ../static so FastAPI can serve it.
// Dev: proxy /api to the local backend on :8000
export default defineConfig({
  plugins: [react()],
  build: { outDir: "../static", emptyOutDir: true },
  server: { proxy: { "/api": "http://localhost:8000" } },
});
