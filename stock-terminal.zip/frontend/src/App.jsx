import { useState, useEffect, useMemo, useCallback } from "react";

/* Stock Terminal — live frontend. Talks to the FastAPI backend.
   Same origin in production (served by the API), so API_BASE is "". */
const API_BASE = "";

const C = {
  bg:"#0a0e14", panel:"#11161f", panel2:"#0d1219", line:"#1c2330",
  ink:"#e6edf3", dim:"#7d8896", faint:"#4a5564",
  green:"#3fd07d", red:"#ff5d6c", amber:"#ffb454", blue:"#5aa9ff",
};
const scoreTier = (s) =>
  s>=8?{label:"STRONG",c:C.green,bg:"rgba(63,208,125,0.12)"}:
  s>=6?{label:"BUY",c:"#7fe0a8",bg:"rgba(63,208,125,0.08)"}:
  s>=4?{label:"WATCH",c:C.amber,bg:"rgba(255,180,84,0.10)"}:
  s>=1?{label:"WEAK",c:C.dim,bg:"rgba(125,136,150,0.10)"}:
       {label:"AVOID",c:C.red,bg:"rgba(255,93,108,0.10)"};
const rsiColor=(r)=>r>70?C.amber:r<35?C.red:C.green;
const sign=(n)=>(n>0?"+":"")+n.toFixed(1);
const fmt=(n)=>"₹"+n.toLocaleString("en-IN",{maximumFractionDigits:1});

export default function App(){
  const [rows,setRows]=useState([]);
  const [updated,setUpdated]=useState(null);
  const [tab,setTab]=useState("all");
  const [sortKey,setSortKey]=useState("score");
  const [open,setOpen]=useState(null);
  const [refreshing,setRefreshing]=useState(false);
  const [err,setErr]=useState("");
  const [token,setToken]=useState(()=>localStorage.getItem("st_token")||"");

  const loadData=useCallback(async()=>{
    try{
      const r=await fetch(`${API_BASE}/api/data`);
      const j=await r.json();
      setRows(j.results||[]);
      setUpdated(j.last_updated);
      setErr("");
    }catch(e){ setErr("Cannot reach backend. Is the service awake?"); }
  },[]);

  useEffect(()=>{ loadData(); },[loadData]);

  // poll while a refresh is running
  useEffect(()=>{
    if(!refreshing) return;
    const id=setInterval(async()=>{
      try{
        const r=await fetch(`${API_BASE}/api/status`);
        const j=await r.json();
        if(!j.running){ setRefreshing(false); loadData(); }
      }catch{}
    },2500);
    return ()=>clearInterval(id);
  },[refreshing,loadData]);

  const triggerRefresh=async()=>{
    let t=token;
    if(!t){ t=prompt("Enter refresh token:")||""; if(!t)return; setToken(t); localStorage.setItem("st_token",t); }
    setErr("");
    try{
      const r=await fetch(`${API_BASE}/api/refresh`,{method:"POST",headers:{"X-Token":t}});
      if(r.status===401){ setErr("Bad token. Tap refresh again to re-enter."); localStorage.removeItem("st_token"); setToken(""); return; }
      const j=await r.json();
      if(j.started) setRefreshing(true);
      else if(j.reason) setRefreshing(true); // already running -> just poll
    }catch{ setErr("Refresh failed to start."); }
  };

  const display=useMemo(()=>{
    let r=[...rows];
    if(tab==="buy")r=r.filter(x=>x.score>=6);
    if(tab==="watch")r=r.filter(x=>x.score>=4&&x.score<6);
    if(tab==="avoid")r=r.filter(x=>x.score<4);
    r.sort((a,b)=>sortKey==="name"?a.name.localeCompare(b.name):(b[sortKey]??0)-(a[sortKey]??0));
    return r;
  },[rows,tab,sortKey]);

  const stats=useMemo(()=>{
    const buys=rows.filter(x=>x.score>=6).length;
    const avoids=rows.filter(x=>x.score<4).length;
    const top=[...rows].sort((a,b)=>b.score-a.score)[0];
    const avgRsi=rows.length?rows.reduce((s,x)=>s+x.rsi,0)/rows.length:0;
    return {buys,avoids,top,avgRsi};
  },[rows]);

  const when=updated?new Date(updated).toLocaleString("en-IN",{dateStyle:"medium",timeStyle:"short"}):"never";

  return (
    <div style={{fontFamily:"'IBM Plex Mono',ui-monospace,monospace",background:C.bg,color:C.ink,minHeight:"100vh",fontSize:13}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
        *{box-sizing:border-box}body{margin:0}
        .tb{cursor:pointer;padding:8px 16px;border-radius:7px;font-size:12px;font-weight:600;border:1px solid transparent;background:transparent;color:${C.dim}}
        .tb.on{background:${C.panel};color:${C.ink};border-color:${C.line}}
        .rw:hover{background:${C.panel}}
        .so{cursor:pointer}.so:hover{color:${C.blue}}
        .btn{cursor:pointer;border:1px solid ${C.line};background:${C.panel};color:${C.ink};border-radius:8px;padding:9px 16px;font-family:inherit;font-size:12px;font-weight:600}
        .btn:hover{border-color:${C.blue}}
        @keyframes rise{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
        @keyframes spin{to{transform:rotate(360deg)}}
      `}</style>

      <div style={{borderBottom:`1px solid ${C.line}`,padding:"16px 24px",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,background:C.bg,zIndex:10,flexWrap:"wrap",gap:12}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <div style={{width:34,height:34,borderRadius:8,background:`linear-gradient(135deg,${C.green},${C.blue})`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,color:"#0a0e14",fontFamily:"'Space Grotesk'"}}>R</div>
          <div>
            <div style={{fontFamily:"'Space Grotesk'",fontSize:17,fontWeight:700}}>STOCK TERMINAL</div>
            <div style={{fontSize:11,color:C.faint}}>NSE · updated {when}</div>
          </div>
        </div>
        <button className="btn" onClick={triggerRefresh} disabled={refreshing} style={{opacity:refreshing?0.7:1,display:"flex",alignItems:"center",gap:8}}>
          <span style={{display:"inline-block",animation:refreshing?"spin 1s linear infinite":"none"}}>↻</span>
          {refreshing?"Refreshing…":"Refresh"}
        </button>
      </div>

      <div style={{maxWidth:1180,margin:"0 auto",padding:"22px 24px 60px"}}>
        {err&&<div style={{background:"rgba(255,93,108,0.10)",border:`1px solid #3a1f24`,color:C.red,padding:"10px 14px",borderRadius:9,marginBottom:16,fontSize:12}}>{err}</div>}
        {!rows.length&&!err&&<div style={{color:C.faint,padding:"40px 0",textAlign:"center"}}>No data yet. Tap Refresh to fetch (first run takes ~30s).</div>}

        {rows.length>0&&<>
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:22}}>
            {[["BUY SIGNALS",stats.buys,C.green,"score ≥ 6"],["AVOID",stats.avoids,C.red,"score < 4"],["TOP",stats.top?.ticker??"—",C.blue,stats.top?`score ${stats.top.score}/10`:""],["AVG RSI",stats.avgRsi.toFixed(0),rsiColor(stats.avgRsi),stats.avgRsi>60?"hot":stats.avgRsi<40?"cold":"neutral"]].map(([l,v,c,sub])=>(
              <div key={l} style={{background:C.panel,border:`1px solid ${C.line}`,borderRadius:10,padding:"13px 15px"}}>
                <div style={{fontSize:10,color:C.faint,letterSpacing:1,marginBottom:7}}>{l}</div>
                <div style={{fontSize:23,fontWeight:700,color:c,fontFamily:"'Space Grotesk'"}}>{v}</div>
                <div style={{fontSize:11,color:C.dim}}>{sub}</div>
              </div>
            ))}
          </div>

          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14,flexWrap:"wrap",gap:10}}>
            <div style={{display:"flex",gap:4,background:C.panel2,padding:5,borderRadius:9,border:`1px solid ${C.line}`}}>
              {[["all",`ALL ${rows.length}`],["buy","BUY"],["watch","WATCH"],["avoid","AVOID"]].map(([k,l])=>(
                <button key={k} className={"tb"+(tab===k?" on":"")} onClick={()=>{setOpen(null);setTab(k);}}>{l}</button>
              ))}
            </div>
            <div style={{display:"flex",gap:8,alignItems:"center",fontSize:11,color:C.dim}}>sort:
              {[["score","Score"],["ret_1w","1W"],["ret_1m","1M"],["rsi","RSI"],["vol_ratio","Vol"]].map(([k,l])=>(
                <span key={k} className="so" onClick={()=>setSortKey(k)} style={{color:sortKey===k?C.blue:C.dim,fontWeight:sortKey===k?700:400}}>{l}</span>
              ))}
            </div>
          </div>

          <div style={{background:C.panel,border:`1px solid ${C.line}`,borderRadius:12,overflow:"hidden"}}>
            <div style={{display:"grid",gridTemplateColumns:"34px 1fr 92px 60px 70px 70px 76px 92px",gap:8,padding:"11px 16px",background:C.panel2,borderBottom:`1px solid ${C.line}`,fontSize:10,color:C.faint,letterSpacing:.8,fontWeight:600}}>
              <div>#</div><div>STOCK</div><div>PRICE</div><div>RSI</div><div>1W</div><div>1M</div><div>52WH</div><div style={{textAlign:"right"}}>SCORE</div>
            </div>
            {display.map((s,i)=>{
              const t=scoreTier(s.score),isOpen=open===s.ticker;
              return (
                <div key={s.ticker} style={{borderBottom:`1px solid ${C.line}`,animation:`rise .25s ${i*0.03}s both`}}>
                  <div className="rw" onClick={()=>setOpen(isOpen?null:s.ticker)} style={{display:"grid",gridTemplateColumns:"34px 1fr 92px 60px 70px 70px 76px 92px",gap:8,padding:"13px 16px",cursor:"pointer",alignItems:"center",background:isOpen?C.panel2:"transparent"}}>
                    <div style={{color:C.faint,fontWeight:600}}>{i+1}</div>
                    <div><div style={{fontWeight:600,fontFamily:"'Space Grotesk'"}}>{s.name}</div><div style={{fontSize:10,color:C.faint}}>{s.ticker}</div></div>
                    <div style={{fontWeight:600}}>{fmt(s.price)}</div>
                    <div style={{color:rsiColor(s.rsi),fontWeight:600}}>{s.rsi.toFixed(0)}</div>
                    <div style={{color:s.ret_1w>=0?C.green:C.red}}>{sign(s.ret_1w)}%</div>
                    <div style={{color:s.ret_1m>=0?C.green:C.red}}>{sign(s.ret_1m)}%</div>
                    <div style={{color:C.dim}}>{s.pct_52w_high.toFixed(0)}%</div>
                    <div style={{textAlign:"right",display:"flex",justifyContent:"flex-end",alignItems:"center",gap:6}}>
                      <span style={{fontSize:10,fontWeight:700,color:t.c,background:t.bg,padding:"2px 7px",borderRadius:5}}>{t.label}</span>
                      <span style={{fontWeight:700,fontFamily:"'Space Grotesk'",color:t.c,minWidth:24}}>{s.score}</span>
                    </div>
                  </div>
                  {isOpen&&(
                    <div style={{padding:"4px 16px 18px 50px",display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
                      <Panel title="INDICATORS">
                        <Kv k="RSI(14)" v={`${s.rsi.toFixed(1)} ${s.rsi>70?"⚠":s.rsi<35?"◆":"✓"}`} c={rsiColor(s.rsi)}/>
                        <Kv k="MACD hist" v={`${s.macd_hist>0?"▲":"▼"} ${Math.abs(s.macd_hist).toFixed(2)}`} c={s.macd_hist>0?C.green:C.red}/>
                        <Kv k="Vol ratio" v={`${s.vol_ratio.toFixed(2)}×`} c={s.vol_ratio>1.5?C.amber:C.dim}/>
                        <div style={{marginTop:10,display:"flex",gap:6}}>
                          {[["20",s.ma20],["50",s.ma50],["200",s.ma200]].map(([n,v])=>(
                            <div key={n} style={{flex:1,textAlign:"center",background:C.bg,borderRadius:6,padding:"6px 0",border:`1px solid ${C.line}`}}>
                              <div style={{fontSize:9,color:C.faint}}>MA{n}</div>
                              <div style={{fontSize:11,color:s.price>v?C.green:C.red,fontWeight:600}}>{s.price>v?"▲":"▼"}{Math.round(v)}</div>
                            </div>
                          ))}
                        </div>
                      </Panel>
                      <Panel title="CANDLE PATTERNS">
                        {s.patterns.map((p,j)=>(<div key={j} style={{fontSize:12,color:p.includes("No clear")?C.faint:C.ink,marginBottom:6,fontWeight:p.includes("No clear")?400:600}}>🕯 {p}</div>))}
                      </Panel>
                      <Panel title={`WHY · ${t.label}`}>
                        <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
                          {s.reasons.length?s.reasons.map((r,j)=>{const neg=r.includes("Overbought")||r.includes("Oversold");return <span key={j} style={{fontSize:10,padding:"3px 8px",borderRadius:5,background:neg?"rgba(255,93,108,0.10)":"rgba(90,169,255,0.10)",color:neg?C.red:C.blue,border:`1px solid ${neg?"#3a1f24":"#1c2d44"}`}}>{r}</span>;}):<span style={{fontSize:11,color:C.faint}}>No bullish factors</span>}
                        </div>
                      </Panel>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <div style={{marginTop:16,fontSize:11,color:C.faint,lineHeight:1.7}}>
            10-point trend-alignment composite from your analysis engine. Data via yfinance (~15 min delayed). <span style={{color:C.dim}}>Not investment advice.</span>
          </div>
        </>}
      </div>
    </div>
  );
}

function Panel({title,children}){return(<div style={{background:C.panel2,border:`1px solid ${C.line}`,borderRadius:9,padding:"12px 14px"}}><div style={{fontSize:9,color:C.faint,letterSpacing:1,marginBottom:10,fontWeight:600}}>{title}</div>{children}</div>);}
function Kv({k,v,c}){return(<div style={{display:"flex",justifyContent:"space-between",marginBottom:7}}><span style={{fontSize:11,color:"#9aa5b1"}}>{k}</span><span style={{fontSize:11,fontWeight:600,color:c}}>{v}</span></div>);}
